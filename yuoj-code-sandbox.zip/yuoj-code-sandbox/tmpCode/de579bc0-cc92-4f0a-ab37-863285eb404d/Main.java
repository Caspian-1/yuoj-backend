package main

import (
	"fmt"
	"os"
	"strconv"
)

func main() {
	// 从命令行参数获取两个数字
	a, _ := strconv.Atoi(os.Args[1])
	b, _ := strconv.Atoi(os.Args[2])
	
	// 计算并输出结果
	fmt.Println(a * b)
}
