package com.yupi.yuojcodesandbox;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuojCodeSandboxApplicationTests {

    @Test
    void contextLoads() {
    }

}
