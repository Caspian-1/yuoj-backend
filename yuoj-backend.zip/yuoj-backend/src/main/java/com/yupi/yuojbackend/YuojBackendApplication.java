package com.yupi.yuojbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YuojBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(YuojBackendApplication.class, args);
    }

}
