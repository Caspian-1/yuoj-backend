package com.yupi.yuojbackendgetway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuojBackendGetwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
