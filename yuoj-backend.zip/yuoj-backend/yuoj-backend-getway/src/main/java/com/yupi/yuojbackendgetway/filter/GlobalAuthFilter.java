package com.yupi.yuojbackendgetway.filter;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;

@Component
public class GlobalAuthFilter implements GlobalFilter, Ordered {

    private AntPathMatcher antPathMatcher = new AntPathMatcher();

    @Override
    /**
     * 实现网关过滤器的方法，用于请求过滤和权限校验
     * @param exchange 当前的服务器网络交换对象，包含请求和响应信息
     * @param chain 网关过滤器链，用于传递请求到下一个过滤器
     * @return Mono<Void> 表示异步操作的结果，当操作完成时发出完成信号
     */
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        // 获取当前请求对象
        ServerHttpRequest serverHttpRequest = exchange.getRequest();
        // 获取请求路径
        String path = serverHttpRequest.getURI().getPath();
        // 判断路径中是否包含 inner，只允许内部调用
        if (antPathMatcher.match("/**/inner/**", path)) {
            // 创建响应对象
            ServerHttpResponse response = exchange.getResponse();
            // 设置响应状态码为403禁止访问
            response.setStatusCode(HttpStatus.FORBIDDEN);
            // 创建数据缓冲工厂
            DataBufferFactory dataBufferFactory = response.bufferFactory();
            // 创建包含"无权限"信息的响应体
            DataBuffer dataBuffer = dataBufferFactory.wrap("无权限".getBytes(StandardCharsets.UTF_8));
            // 返回包含错误信息的响应
            return response.writeWith(Mono.just(dataBuffer));
        }
        // todo 统一权限校验，通过 JWT 获取登录用户信息
        return chain.filter(exchange);
    }

    /**
     * 优先级提到最高
     * @return
     */
    @Override
    public int getOrder() {
        return 0;
    }
}
