package com.yupi.yuojbackendgetway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.reactive.CorsWebFilter;
import org.springframework.web.cors.reactive.UrlBasedCorsConfigurationSource;
import org.springframework.web.util.pattern.PathPatternParser;

import java.util.Arrays;

// 处理跨域
@Configuration
public class CorsConfig {

/**
 * 配置跨域资源共享(CORS)的Web过滤器
 * 用于解决前端跨域访问问题
 *
 * @return CorsWebFilter 配置好的跨域过滤器实例
 */
    @Bean
    public CorsWebFilter corsFilter() {
    // 创建CORS配置对象
        CorsConfiguration config = new CorsConfiguration();
    // 允许所有的HTTP方法（GET, POST, PUT, DELETE等）
        config.addAllowedMethod("*");
    // 允许发送凭证信息（如cookies、HTTP认证等）
        config.setAllowCredentials(true);
        // todo 实际改为线上真实域名、本地域名
        config.setAllowedOriginPatterns(Arrays.asList("*"));
        config.addAllowedHeader("*");
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource(new PathPatternParser());
        source.registerCorsConfiguration("/**", config);
        return new CorsWebFilter(source);
    }
}