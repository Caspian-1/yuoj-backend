package com.yupi.yuojbackendquestionservice.config;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis Plus 配置
 *
 * @author https://github.com/liyupi
 */
@Configuration
@MapperScan("com.yupi.yuojbackendquestionservice.mapper")
public class MyBatisPlusConfig {

    /**
     * 拦截器配置
     * 该方法用于配置MyBatis-Plus的拦截器，特别是添加分页插件
     * @return 返回配置好的MybatisPlusInterceptor实例
     */
    @Bean  // 将该方法返回的对象交给Spring容器管理
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
    // 创建MybatisPlusInterceptor实例，用于添加各种内部拦截器
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        // 分页插件
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor(DbType.MYSQL));
        return interceptor;
    }
}