package com.yupi.yuojbackendquestionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuojBackendQuestionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
